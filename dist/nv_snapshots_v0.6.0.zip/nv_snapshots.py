"""A project collection manager plugin for novelibre.

Requires Python 3.6+
Copyright (c) 2025 Peter Triesberger
For further information see https://github.com/peter88213/nv_snapshots
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""

from pathlib import Path

import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_snapshots',
        LOCALE_PATH,
        languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message

from abc import ABC, abstractmethod



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass



class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller


FEATURE = _('Snapshots')

icons = {
    'snapshot': None,
}
import webbrowser



class Nvsnapshotshelp:

    HELP_URL = f'{_("https://peter88213.github.io/nvhelp-en")}/nv_snapshots/'

    @classmethod
    def open_help_page(cls):
        webbrowser.open(cls.HELP_URL)

import platform



class GenericKeys:

    DELETE = ('<Delete>', _('Del'))
    OPEN_HELP = ('<F1>', 'F1')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')
    MAKE_SNAPSHOT = ('<Control-Alt-s>', f'{_("Ctrl")}-Alt-S')



class GenericMouse:

    LEFT_CLICK = '<Button-1>'
    MOVE_NODE = '<Alt-B1-Motion>'


class MacKeys(GenericKeys):

    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')
    MAKE_SNAPSHOT = ('<Command-Alt-s>', 'Cmd-Alt-S')


class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')

if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
    MOUSE = GenericMouse
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
    MOUSE = GenericMouse
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
    MOUSE = GenericMouse
else:
    PLATFORM = ''
    KEYS = GenericKeys()
    MOUSE = GenericMouse

from datetime import datetime
import glob
import json
from pathlib import Path
import re
import zipfile



try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation(
            'novelibre',
            LOCALE_PATH,
            languages=[CURRENT_LANGUAGE],
        )
        _ = t.gettext
    except:

        def _(message):
            return message


ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERLIST_SUFFIX = '_chapterlist_tmp'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
ELEMENT_NOTES_SUFFIX = '_element_note_report',
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MAJOR_MARKER = _('Major Character')
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
MINOR_MARKER = _('Minor Character')
PARTLIST_SUFFIX = '_partlist_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
TIMETABLE_SUFFIX = '_tt_tmp'
XREF_SUFFIX = '_xref'


class Error(Exception):
    pass


class Notification(Error):
    pass


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr

from tkinter import ttk

import tkinter as tk
from tkinter import ttk



class TextBox(tk.Text):

    def __init__(self, master=None, scrollbar=True, **kw):
        if kw.get('font', None) is None:
            kw['font'] = 'Courier 10'
        if scrollbar:
            self.frame = ttk.Frame(master)
            self.vbar = ttk.Scrollbar(self.frame)
            self.vbar.pack(side='right', fill='y')

            kw.update({'yscrollcommand': self.vbar.set})
            tk.Text.__init__(self, self.frame, **kw)
            self.pack(side='left', fill='both', expand=True)
            self.vbar['command'] = self.yview

            text_meths = vars(tk.Text).keys()
            methods = (
                vars(tk.Pack).keys()
                | vars(tk.Grid).keys()
                | vars(tk.Place).keys()
            )
            methods = methods.difference(text_meths)

            for m in methods:
                if m[0] != '_' and m != 'config' and m != 'configure':
                    setattr(self, m, getattr(self.frame, m))
        else:
            tk.Text.__init__(self, master, **kw)

        self.hasChanged = False
        self.bind('<KeyRelease>', self._on_edit)

    def clear(self):
        self.delete('1.0', 'end')
        self.hasChanged = False

    def get_text(self):
        text = self.get('1.0', 'end').strip(' \n')
        return text

    def set_text(self, text):
        self.clear()
        if text:
            self.insert('end', text)
            self.edit_reset()

    def _on_edit(self, event=None):
        self.hasChanged = True



class MyStringVar(tk.StringVar):

    def set(self, value):
        if value is None:
            value = ''
        super().set(value)

    def get(self):
        value = super().get()
        if value == '':
            value = None
        return value


class IndexCard(tk.Frame):

    def __init__(
            self,
            master=None,
            cnf={},
            fg='black',
            bg='white',
            font=None,
            scrollbar=True,
            **kw
    ):
        super().__init__(master=master, cnf=cnf, **kw)
        self.title = MyStringVar(value='')
        self.titleEntry = tk.Entry(
            self,
            bg=bg,
            bd=0,
            textvariable=self.title,
            relief='flat',
            font=font,
        )
        self.titleEntry.config(
            {
                'background': bg,
                'foreground': fg,
                'insertbackground': fg,
            }
        )
        self.titleEntry.pack(fill='x', ipady=6)

        tk.Frame(self, bg='red', height=1, bd=0).pack(fill='x')
        tk.Frame(self, bg=bg, height=1, bd=0).pack(fill='x')

        self.bodyBox = TextBox(
            self,
            scrollbar=scrollbar,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            padx=5,
            pady=5,
            bg=bg,
            fg=fg,
            insertbackground=fg,
            font=font,
        )
        self.bodyBox.pack(fill='both', expand=True)

    def lock(self):
        self.titleEntry.config(state='disabled')
        self.bodyBox.config(state='disabled')

    def unlock(self):
        self.titleEntry.config(state='normal')
        self.bodyBox.config(state='normal')


class SnapshotView(tk.Toplevel, SubController):
    HEIGHT_BIAS = 20

    def __init__(self, model, view, controller, windowPosition, prefs):
        super().__init__()
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self.prefs = prefs
        windowSize = self.prefs['window_size'].split('+')[0]
        self.geometry(f"{windowSize}{windowPosition}")

        self.title(FEATURE)
        self.statusText = ''

        self.lift()
        self.focus()

        self._mainMenu = tk.Menu(self)
        self.config(menu=self._mainMenu)

        self._mainWindow = ttk.Frame(self)
        self._mainWindow.pack(fill='both', padx=2, pady=2, expand=True)

        self._treeWindow = ttk.Panedwindow(
            self._mainWindow,
            orient='horizontal',
        )
        self._treeWindow.pack(fill='both', expand=True)

        self._treeView = ttk.Treeview(self._treeWindow, selectmode='browse')
        scrollY = ttk.Scrollbar(
            self._treeView,
            orient='vertical',
            command=self._treeView.yview,
        )
        self._treeView.configure(yscrollcommand=scrollY.set)
        scrollY.pack(side='right', fill='y')
        self._treeView.pack(side='left')
        self._treeWindow.add(self._treeView)
        self._treeView.bind('<<TreeviewSelect>>', self._on_select_node)

        self._indexCard = IndexCard(self._treeWindow, bd=2, relief='ridge')
        self._indexCard.pack(side='right')
        self._treeWindow.add(self._indexCard)

        self._treeWindow.update()
        self._treeWindow.sashpos(0, self.prefs['tree_width'])

        self._fileMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(
            label=_('File'),
            menu=self._fileMenu,
        )
        self._fileMenu.add_command(
            label=_('Open Snapshot folder'),
            command=self._event('<<open_folder>>'),
        )
        self._fileMenu.add_separator()
        self._fileMenu.add_command(
            label=_('Snapshot'),
            accelerator=KEYS.MAKE_SNAPSHOT[1],
            image=icons.get('snapshot', None),
            compound='left',
            command=self._event('<<make_snapshot>>'),
        )
        self._fileMenu.add_separator()
        self._fileMenu.add_command(
            label=_('Remove'),
            accelerator=KEYS.DELETE[1],
            command=self._event('<<remove_snapshot>>'),
        )
        self._fileMenu.add_command(
            label=_('Revert'),
            command=self._event('<<revert>>'),
        )
        self._fileMenu.add_separator()
        self._fileMenu.add_command(
            label=_('Close'),
            accelerator=KEYS.QUIT_PROGRAM[1],
            command=self.on_quit,
        )

        self._helpMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(
            label=_('Help'),
            menu=self._helpMenu,
        )
        self._helpMenu.add_command(
            label=_('Online help'),
            accelerator=KEYS.OPEN_HELP[1],
            command=self._event('<<open_help>>'),
        )

        self.protocol("WM_DELETE_WINDOW", self.on_quit)
        if PLATFORM != 'win':
            self.bind(KEYS.QUIT_PROGRAM[0], self.on_quit)
        self.bind(KEYS.MAKE_SNAPSHOT[0], self._event('<<make_snapshot>>'))
        self.bind(KEYS.OPEN_HELP[0], self._event('<<open_help>>'))
        self.bind(KEYS.DELETE[0], self._event('<<remove_snapshot>>'))

        self.update_idletasks()
        self.geometry(f"{windowSize}{windowPosition}")

        self.isOpen = True
        self.element = {}

    def disable_menu(self):
        self._mainMenu.entryconfig(_('File'), state='disabled')

    def enable_menu(self):
        self._mainMenu.entryconfig(_('File'), state='normal')

    def get_selection(self):
        try:
            nodeId = self._treeView.selection()[0]
        except IndexError:
            return None
        else:
            return nodeId

    def reset_tree(self):
        for node in self._treeView.get_children(''):
            self._treeView.delete(node)

    def build_tree(self):
        self.reset_tree()
        for snapshotId in self.snapshots:
            self._treeView.insert(
                '',
                'end',
                snapshotId,
                text=snapshotId,
        )
        self._indexCard.bodyBox.config(state='normal')
        self._indexCard.bodyBox.clear()
        self._indexCard.bodyBox.config(state='disabled')
        self._indexCard.titleEntry.config(state='normal')
        self._indexCard.title.set('')
        self._indexCard.titleEntry.config(state='disabled')

    def on_quit(self, event=None):
        self.prefs['tree_width'] = self._treeWindow.sashpos(0)
        self.prefs['window_size'] = self.winfo_geometry().split('+')[0]
        self.destroy()
        self.isOpen = False

    def _event(self, sequence):

        def callback(*_):
            root = self.master.winfo_toplevel()
            root.event_generate(sequence)

        return callback

    def _on_select_node(self, event=None):
        try:
            self.nodeId = self._treeView.selection()[0]
        except IndexError:
            return

        self.element = self.snapshots[self.nodeId]
        self._set_element_view()

    def _set_element_view(self, event=None):
        self._indexCard.bodyBox.config(state='normal')
        self._indexCard.bodyBox.clear()
        self._indexCard.bodyBox.set_text(self.element.get('description', ''))
        self._indexCard.bodyBox.config(state='disabled')
        self._indexCard.titleEntry.config(state='normal')
        self._indexCard.title.set(self.element.get('title', ''))
        self._indexCard.titleEntry.config(state='disabled')

from tkinter import ttk

from abc import abstractmethod



class ModalDialog(tk.Toplevel):
    OFFSET = 300

    @abstractmethod
    def __init__(self, ui, **kw):
        tk.Toplevel.__init__(self, **kw)
        __, x, y = ui.root.geometry().split('+')
        windowGeometry = f'+{int(x)+self.OFFSET}+{int(y)+self.OFFSET}'
        self.geometry(windowGeometry)
        self.grab_set()
        self.focus()



class SnapshotDialog(ModalDialog):

    def __init__(self, view, service, **kw):
        super().__init__(view, **kw)
        self._ui = view
        self._service = service

        self.title(_('Snapshot description'))
        mainWindow = ttk.Frame(self)
        mainWindow.pack(
            fill='both',
            padx=5,
            pady=5
        )
        self._indexCard = IndexCard(mainWindow, bd=2, relief='ridge')
        self._indexCard.bodyBox['height'] = 13
        self._indexCard.bodyBox['width'] = 40
        self._indexCard.pack()

        buttons_frame = ttk.Frame(mainWindow)
        buttons_frame.pack(fill='both')

        ttk.Button(
            buttons_frame,
            text=_('Ok'),
            command=self._set_description,
        ).pack(padx=5, pady=5, side='left')

        ttk.Button(
            buttons_frame,
            text=_('Cancel'),
            command=self.destroy,
        ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            buttons_frame,
            text=_('Online help'),
            command=self._open_help
        ).pack(padx=5, pady=5, side='right')

        self.resizable(False, False)

        self.bind(KEYS.OPEN_HELP[0], self._open_help)

    def _open_help(self, event=None):
        Nvsnapshotshelp.open_help_page()

    def _set_description(self, event=None):
        self._service.snapshotTitle = self._indexCard.title.get()
        self._service.snapshotComment = self._indexCard.bodyBox.get_text()
        self.destroy()
        self._ui.root.event_generate('<<save_snapshot>>')





class GenericKeys:

    ADD_CHILD = ('<Control-Alt-n>', f'{_("Ctrl")}-Alt-N')
    ADD_ELEMENT = ('<Control-n>', f'{_("Ctrl")}-N')
    ADD_PARENT = ('<Control-Alt-N>', f'{_("Ctrl")}-Alt-{_("Shift")}-N')
    BACK = ('<Alt-Left>', f'{_("Alt-Left")}')
    CHAPTER_LEVEL = ('<Control-Alt-c>', f'{_("Ctrl")}-Alt-C')
    COPY = ('<Control-c>', f'{_("Ctrl")}-C')
    CUT = ('<Control-x>', f'{_("Ctrl")}-X')
    DELETE = ('<Delete>', _('Del'))
    DETACH_PROPERTIES = ('<Control-Alt-d>', f'{_("Ctrl")}-Alt-D')
    FOLDER = ('<Control-p>', f'{_("Ctrl")}-P')
    FORWARD = ('<Alt-Right>', f'{_("Alt-Right")}')
    LOCK_PROJECT = ('<Control-l>', f'{_("Ctrl")}-L')
    NEXT = ('<Alt-Down>', f'{_("Alt-Down")}')
    OPEN_HELP = ('<F1>', 'F1')
    OPEN_PROJECT = ('<Control-o>', f'{_("Ctrl")}-O')
    PASTE = ('<Control-v>', f'{_("Ctrl")}-V')
    PREVIOUS = ('<Alt-Up>', f'{_("Alt-Up")}')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')
    REFRESH_TREE = ('<F5>', 'F5')
    RELOAD_PROJECT = ('<Control-r>', f'{_("Ctrl")}-R')
    RESTORE_BACKUP = ('<Control-b>', f'{_("Ctrl")}-B')
    RESTORE_STATUS = ('<Escape>', 'Esc')
    SAVE_AS = ('<Control-S>', f'{_("Ctrl")}-{_("Shift")}-S')
    SAVE_PROJECT = ('<Control-s>', f'{_("Ctrl")}-S')
    TOGGLE_PROPERTIES = ('<Control-Alt-t>', f'{_("Ctrl")}-Alt-T')
    TOGGLE_VIEWER = ('<Control-t>', f'{_("Ctrl")}-T')
    UNLOCK_PROJECT = ('<Control-u>', f'{_("Ctrl")}-U')



class GenericMouse:

    LEFT_CLICK = '<Button-1>'
    MOVE_NODE = '<Alt-B1-Motion>'
    RIGHT_CLICK = '<Button-3>'


class MacKeys(GenericKeys):

    ADD_CHILD = ('<Command-Alt-n>', 'Cmd-Alt-N')
    ADD_ELEMENT = ('<Command-n>', 'Cmd-N')
    ADD_PARENT = ('<Command-Alt-Shift-N>', 'Cmd-Alt-Shift-N')
    CHAPTER_LEVEL = ('<Command-Alt-c>', 'Cmd-Alt-C')
    COPY = ('<Command-c>', 'Cmd-C')
    CUT = ('<Command-x>', 'Cmd-X')
    DETACH_PROPERTIES = ('<Command-Alt-d>', 'Cmd-Alt-D')
    FOLDER = ('<Command-p>', 'Cmd-P')
    LOCK_PROJECT = ('<Command-l>', 'Cmd-L')
    OPEN_PROJECT = ('<Command-o>', 'Cmd-O')
    PASTE = ('<Command-v>', 'Cmd-V')
    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')
    RELOAD_PROJECT = ('<Command-r>', 'Cmd-R')
    RESTORE_BACKUP = ('<Command-b>', 'Cmd-B')
    SAVE_AS = ('<Command-S>', 'Cmd-Shift-S')
    SAVE_PROJECT = ('<Command-s>', 'Cmd-S')
    TOGGLE_PROPERTIES = ('<Command-Alt-t>', 'Cmd-Alt-T')
    TOGGLE_VIEWER = ('<Command-t>', 'Cmd-T')
    UNLOCK_PROJECT = ('<Command-u>', 'Cmd-U')


class MacMouse(GenericMouse):

    RIGHT_CLICK = '<Button-2>'


class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')


class WindowsMouse(GenericMouse):

    BACK_CLICK = '<Button-4>'
    FORWARD_CLICK = '<Button-5>'

if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
    MOUSE = WindowsMouse()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
    MOUSE = GenericMouse()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
    MOUSE = MacMouse()
else:
    PLATFORM = ''
    KEYS = GenericKeys()
    MOUSE = GenericMouse()



def open_document(document):
    if PLATFORM == 'win':
        os.startfile(norm_path(document))
        return

    if PLATFORM == 'ix':
        os.system('xdg-open "%s"' % norm_path(document))
        return

    if PLATFORM == 'mac':
        os.system('open "%s"' % norm_path(document))


class SnapshotService(SubController):
    INI_FILENAME = 'snapshots.ini'
    INI_FILEPATH = '.novx/config'
    SETTINGS = dict(
        last_open='',
        tree_width='260',
        window_size='600x300',
        snapshot_subdir='Snapshots',
    )
    OPTIONS = {}
    ICON = 'snapshot'

    ZIP_EXTENSION = '.zip'
    DESC_EXTENSION = '.txt'

    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            configDir = '.'
        self.iniFile = f'{configDir}/{self.INI_FILENAME}'
        self.configuration = self._mdl.nvService.new_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS
        )
        self.prefs = {}
        self.prefs.update(self.configuration.settings)
        self.prefs.update(self.configuration.options)

        try:
            path = os.path.dirname(sys.argv[0])
            if not path:
                path = '.'
            self.icon = tk.PhotoImage(file=f'{path}/icons/{self.ICON}.png')
        except:
            self.icon = None

        self.snapshotView = None
        self.prjSnapshots = {}

        self._snapshotId = None
        self._isoDate = None
        self._projectFile = None
        self._zipPath = None

        self._ui.root.bind('<<save_snapshot>>', self._save_snapshot)
        self.snapshotTitle = None
        self.snapshotComment = None

    def disable_menu(self):
        self.snapshotView.disable_menu()

    def enable_menu(self):
        self.snapshotView.enable_menu()

    def make_snapshot(self, event=None):
        self._ui.restore_status()
        self._ui.propertiesView.apply_changes()
        if self._mdl.prjFile is None:
            return

        if self._mdl.prjFile.filePath is None:
            if not self._ctrl.save_project():
                return

        if self._mdl.isModified:
            if self._ui.ask_yes_no(
                message=_('Save changes?')
            ):
                self._ctrl.save_project()
            else:
                self._ui.set_status(f'#{_("Action canceled by user")}.')
                return

        os.makedirs(self._get_snapshot_dir(), exist_ok=True)

        __, projectFile = os.path.split(self._mdl.prjFile.filePath)
        prjName, __ = os.path.splitext(projectFile)
        prjFileTimestamp = os.path.getmtime(self._mdl.prjFile.filePath)
        prjFileDate = (datetime.fromtimestamp(prjFileTimestamp))
        self._isoDate = prjFileDate.replace(microsecond=0).isoformat()
        self._snapshotId = f"{prjName}.{self._isoDate.replace(':', '.')}"
        self._zipPath = self._get_zipfile_path(self._snapshotId)
        if os.path.isfile(self._zipPath):
            self._ui.set_status(f'#{_("Snapshot already exists")}.')
            return

        SnapshotDialog(self._ui, self)

    def on_close(self):
        self.prjSnapshots.clear()
        self.snapshotView.reset_tree()

    def on_quit(self):
        if self.snapshotView:
            if self.snapshotView.isOpen:
                self.snapshotView.on_quit()

        for keyword in self.prefs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.prefs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.prefs[keyword]

    def refresh(self):
        self._collect_snapshots()
        if self.snapshotView:
            self.snapshotView.snapshots = self.prjSnapshots
            self.snapshotView.build_tree()

    def start_manager(self):

        if self.snapshotView:
            if self.snapshotView.isOpen:
                if self.snapshotView.state() == 'iconic':
                    self.snapshotView.state('normal')
                self.snapshotView.lift()
                self.snapshotView.focus()
                return

        __, x, y = self._ui.root.geometry().split('+')
        offset = 100
        windowPosition = f'+{int(x)+offset}+{int(y)+offset}'
        self.snapshotView = SnapshotView(
            self._mdl,
            self._ui,
            self._ctrl,
            windowPosition,
            self.prefs,
        )
        if self.icon:
            self.snapshotView.iconphoto(False, self.icon)

        self._bind_events()
        self.refresh()

    def _bind_events(self):
        event_callbacks = {
            '<<make_snapshot>>': self.make_snapshot,
            '<<open_help>>': self._open_help,
            '<<remove_snapshot>>': self._remove_snapshot,
            '<<revert>>': self._revert,
            '<<open_folder>>': self._open_folder,
        }
        for sequence, callback in event_callbacks.items():
            self.snapshotView.master.winfo_toplevel().bind(sequence, callback)

    def _collect_snapshots(self):
        projectDir, projectFile = os.path.split(self._mdl.prjFile.filePath)
        snapshotDir = os.path.join(
            projectDir,
            self.prefs['snapshot_subdir']
        )
        if not os.path.isdir(snapshotDir):
            return

        self.prjSnapshots.clear()
        prjName, __ = os.path.splitext(projectFile)
        pattern = f'{prjName}.*{self.ZIP_EXTENSION}'
        prjSnapshotFiles = glob.glob(
            pattern,
            root_dir=snapshotDir,
        )
        prjSnapshotFiles.sort()
        if not prjSnapshotFiles:
            return

        for snapshotFile in prjSnapshotFiles:
            zipPath = os.path.join(snapshotDir, snapshotFile)
            try:
                with zipfile.ZipFile(zipPath, 'r') as z:
                    with z.open('meta.json', 'r') as f:
                        metadata = json.loads(f.read())
            except:
                pass
            else:
                self.prjSnapshots |= metadata

    def _create_document(self, sourcePath, suffix, **kwargs):
        self._ui.restore_status()
        if not os.path.isfile(sourcePath):
            self._ui.set_status(
                (
                    f'!{_("File not found")}: '
                    f'"{norm_path(sourcePath)}".'
                )
            )
            return

        __, extension = os.path.splitext(sourcePath)
        if extension == self._mdl.nvService.get_novx_file_extension():
            novxFile = self._mdl.nvService.new_novx_file(sourcePath)
        elif extension == self._mdl.nvService.get_zipped_novx_file_extension():
            novxFile = self._mdl.nvService.new_zipped_novx_file(sourcePath)
        else:
            self._ui.set_status(f'!{_("File type is not supported")}.')
            return

        novxFile.novel = self._mdl.nvService.new_novel()
        try:
            novxFile.read()
            self._ui.set_status(
                self._ctrl.fileManager.exporter.run(
                    novxFile,
                    suffix,
                )
            )
        except Notification as ex:
            self._ui.set_status(f'#{str(ex)}')
        except Exception as ex:
            self._ui.set_status(f'!{str(ex)}')

    def _get_snapshot_dir(self):
        projectDir, __ = os.path.split(self._mdl.prjFile.filePath)
        return os.path.join(
            projectDir,
            self.prefs.get('snapshot_subdir', ''),
        )

    def _get_zipfile_path(self, snapshotId):
        return os.path.join(
            self._get_snapshot_dir(),
            f'{snapshotId}{self.ZIP_EXTENSION}'
        )

    def _open_folder(self, event=None):
        snapshotDir = self._get_snapshot_dir()
        os.makedirs(snapshotDir, exist_ok=True)
        open_document(snapshotDir)

    def _open_help(self, event=None):
        Nvsnapshotshelp.open_help_page()

    def _remove_snapshot(self, event=None):
        self._ui.restore_status()
        snapshotId = self.snapshotView.get_selection()
        if snapshotId is None:
            return

        try:
            if self._ui.ask_yes_no(
                message=_('Delete the selected snapshot?'),
                detail=self.prjSnapshots[snapshotId].get('title', ''),
                title=FEATURE,
                parent=self.snapshotView,
            ):
                os.remove(self._get_zipfile_path(snapshotId))
        except ValueError as ex:
            self._ui.set_status(
                (
                    f'!{_("Can not remove snapshot")}: '
                    f'{str(ex)}'
                )
            )
        self.refresh()

    def _revert(self, event=None):
        self._ui.restore_status()
        snapshotId = self.snapshotView.get_selection()
        if snapshotId is None:
            return

        try:
            if self._ui.ask_yes_no_cancel(
                message=_('Make a snapshot before restoring the selected one?'),
                detail=self.prjSnapshots[snapshotId].get('title', ''),
                title=_('Revert to the selected snapshot'),
                parent=self.snapshotView,
            ):
                zipFile = self._get_zipfile_path(snapshotId)
                prjFile = self._mdl.prjFile.filePath

        except Exception as ex:
            message = (
                f'!{_("Can not restore snapshot")}: '
                f'{str(ex)}'
            )
        else:
            message = (
                f'{_("Snapshot restored")}: '
                f'"{snapshotId}"'
            )
        finally:
            self._ui.set_status(message)

    def _sanitize_filename(self, filename):
        return re.sub(r'[\\|\/|\:|\*|\?|\"|\<|\>|\|]+', '', filename)

    def _save_snapshot(self, event=None):
        wordCount, totalCount = self._mdl.prjFile.count_words()
        snapshotMetadata = {
            self._snapshotId: {
                'title': self.snapshotTitle,
                'description': self.snapshotComment,
                'date': self._isoDate,
                'work phase': self._mdl.novel.workPhase,
                'words used': wordCount,
                'words total':totalCount,
            }
        }

        try:
            with zipfile.ZipFile(self._zipPath, 'w') as z:

                z.write(
                    self._mdl.prjFile.filePath,
                    arcname=self._projectFile,
                    compress_type=zipfile.ZIP_DEFLATED,
                )

                z.writestr(
                    (
                        f'{self._sanitize_filename(self.snapshotTitle)}'
                        f'{self.DESC_EXTENSION}'
                    ),
                    f'{self.snapshotTitle}\n\n{self.snapshotComment}',
                    compress_type=zipfile.ZIP_DEFLATED,
                )

                z.writestr(
                    'meta.json',
                    json.dumps(snapshotMetadata),
                    compress_type=zipfile.ZIP_DEFLATED,
                )

        except Exception as ex:
            message = f'!{_("Snapshot failed")}: {str(ex)}'
        else:
            message = f'{_("Snapshot generated")} ({self._isoDate})'
        self._ui.set_status(message)
        self.refresh()



class Plugin(PluginBase):
    VERSION = '0.6.0'
    API_VERSION = '5.29'
    DESCRIPTION = 'A snapshot manager'
    URL = 'https://github.com/peter88213/nv_snapshots'

    def disable_menu(self):
        """Disable menu entries when no project is open.        
        
        Overrides the SubController method.
        """
        self._ui.fileMenu.entryconfig(_('Snapshot'), state='disabled')
        self._ui.toolsMenu.entryconfig(FEATURE, state='disabled')
        self.snapshotService.disable_menu()

    def enable_menu(self):
        """Enable menu entries when a project is open.
        
        Overrides the SubController method.
        """
        self._ui.fileMenu.entryconfig(_('Snapshot'), state='normal')
        self._ui.toolsMenu.entryconfig(FEATURE, state='normal')
        self.snapshotService.enable_menu()

    def install(self, model, view, controller):
        """Add a submenu to the 'File' menu.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self.snapshotService = SnapshotService(model, view, controller)
        self._icon = self._get_icon('snapshot.png')

        pos = self._ui.fileMenu.index(_('Save')) - 1
        self._ui.fileMenu.insert_separator(pos)
        pos += 1
        self._ui.fileMenu.insert_command(
            pos,
            label=_('Snapshot'),
            accelerator=KEYS.MAKE_SNAPSHOT[1],
            image=self._icon,
            compound='left',
            command=self.make_snapshot,
            state='disabled',
        )

        self._ui.toolsMenu.add_command(
            label=FEATURE,
            image=self._icon,
            compound='left',
            command=self.start_manager,
            state='disabled',
        )

        self._ui.helpMenu.add_command(
            label=_('Snapshots plugin Online help'),
            image=self._icon,
            compound='left',
            command=self.open_help,
            )
        self._ui.root.bind(KEYS.MAKE_SNAPSHOT[0], self.make_snapshot)

    def on_close(self):
        self.snapshotService.on_close()

    def on_open(self):
        self.snapshotService.refresh()

    def on_quit(self):
        self.snapshotService.on_quit()

    def open_help(self, event=None):
        Nvsnapshotshelp.open_help_page()

    def start_manager(self):
        self.snapshotService.start_manager()

    def make_snapshot(self, event=None):
        self.snapshotService.make_snapshot()

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
            icons['snapshot'] = icon

        except:
            icon = None
        return icon

