"""A project collection manager plugin for novelibre.

Requires Python 3.7+
Copyright (c) 2025 Peter Triesberger
For further information see https://github.com/peter88213/nv_snapshots
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_snapshots',
        LOCALE_PATH,
        languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message

from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon



try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation(
            'novelibre',
            LOCALE_PATH,
            languages=[CURRENT_LANGUAGE],
        )
        _ = t.gettext
    except:

        def _(message):
            return message


ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERLIST_SUFFIX = '_chapterlist_tmp'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
ELEMENT_NOTES_SUFFIX = '_element_note_report',
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MAJOR_MARKER = _('Major Character')
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
MINOR_MARKER = _('Minor Character')
PARTLIST_SUFFIX = '_partlist_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
TIMETABLE_SUFFIX = '_tt_tmp'
XREF_SUFFIX = '_xref'

NO_SCENE_FIELD_1_DEFAULT = _('Plot progress')
NO_SCENE_FIELD_2_DEFAULT = _('Characterization')
NO_SCENE_FIELD_3_DEFAULT = _('World building')
OTHER_SCENE_FIELD_1_DEFAULT = _('Opening')
OTHER_SCENE_FIELD_2_DEFAULT = _('Peak emotional moment')
OTHER_SCENE_FIELD_3_DEFAULT = _('Ending')
CR_FIELD_1_DEFAULT = _('Bio')
CR_FIELD_2_DEFAULT = _('Goals')

STATUS = [
    None,
    _('Outline'),
    _('Draft'),
    _('1st Edit'),
    _('2nd Edit'),
    _('Done')
]

SCENE = ['-', 'A', 'R', 'x']


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr

import platform



class GenericKeys:

    DELETE = ('<Delete>', _('Del'))
    OPEN_HELP = ('<F1>', 'F1')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')
    MAKE_SNAPSHOT = ('<Control-Alt-s>', f'{_("Ctrl")}-Alt-S')



class MacKeys(GenericKeys):

    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')
    MAKE_SNAPSHOT = ('<Command-Alt-s>', 'Cmd-Alt-S')


class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')

if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
else:
    PLATFORM = ''
    KEYS = GenericKeys()


FEATURE = _('Snapshots')

icons = {
    'snapshot': None,
}


def open_document(document):
    if PLATFORM == 'win':
        os.startfile(norm_path(document))
        return

    if PLATFORM == 'ix':
        os.system('xdg-open "%s"' % norm_path(document))
        return

    if PLATFORM == 'mac':
        os.system('open "%s"' % norm_path(document))
import webbrowser



class Nvsnapshotshelp:

    HELP_URL = f'{_("https://peter88213.github.io/nvhelp-en")}/nv_snapshots/'

    @classmethod
    def open_help_page(cls):
        webbrowser.open(cls.HELP_URL)

from datetime import datetime
import glob
import json
from pathlib import Path
import re
import zipfile

from tkinter import ttk

from tkinter import ttk



class TextBox(tk.Text):

    def __init__(self, master=None, scrollbar=True, **kw):
        if kw.get('font', None) is None:
            kw['font'] = 'Courier 10'
        if scrollbar:
            self.frame = ttk.Frame(master)
            self.vbar = ttk.Scrollbar(self.frame)
            self.vbar.pack(side='right', fill='y')

            kw.update({'yscrollcommand': self.vbar.set})
            tk.Text.__init__(self, self.frame, **kw)
            self.pack(side='left', fill='both', expand=True)
            self.vbar['command'] = self.yview

            text_meths = vars(tk.Text).keys()
            methods = (
                vars(tk.Pack).keys()
                | vars(tk.Grid).keys()
                | vars(tk.Place).keys()
            )
            methods = methods.difference(text_meths)

            for m in methods:
                if m[0] != '_' and m != 'config' and m != 'configure':
                    setattr(self, m, getattr(self.frame, m))
        else:
            tk.Text.__init__(self, master, **kw)

        self.hasChanged = False
        self.bind('<KeyRelease>', self._on_edit)

    def clear(self):
        self.delete('1.0', 'end')
        self.hasChanged = False

    def get_text(self):
        text = self.get('1.0', 'end').strip(' \n')
        return text

    def set_text(self, text):
        self.clear()
        if text:
            self.insert('end', text)
            self.edit_reset()

    def _on_edit(self, event=None):
        self.hasChanged = True



class MyStringVar(tk.StringVar):

    def set(self, value):
        if value is None:
            value = ''
        super().set(value)

    def get(self, default=None):
        value = super().get()
        if value == '':
            value = default
            if default is not None:
                self.set(default)
        return value


class IndexCard(tk.Frame):

    def __init__(
            self,
            master=None,
            cnf={},
            fg='black',
            bg='white',
            font=None,
            scrollbar=True,
            **kw
    ):
        super().__init__(master=master, cnf=cnf, **kw)
        self.title = MyStringVar(value='')
        self.titleEntry = tk.Entry(
            self,
            bg=bg,
            bd=0,
            textvariable=self.title,
            relief='flat',
            font=font,
        )
        self.titleEntry.config(
            {
                'background': bg,
                'foreground': fg,
                'insertbackground': fg,
            }
        )
        self.titleEntry.pack(fill='x', ipady=6)

        tk.Frame(self, bg='red', height=1, bd=0).pack(fill='x')
        tk.Frame(self, bg=bg, height=1, bd=0).pack(fill='x')

        self.bodyBox = TextBox(
            self,
            scrollbar=scrollbar,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            padx=5,
            pady=5,
            bg=bg,
            fg=fg,
            insertbackground=fg,
            font=font,
        )
        self.bodyBox.pack(fill='both', expand=True)

    def lock(self):
        self.titleEntry.config(state='disabled')
        self.bodyBox.config(state='disabled')

    def unlock(self):
        self.titleEntry.config(state='normal')
        self.bodyBox.config(state='normal')
from abc import abstractmethod



class ModalDialog(tk.Toplevel):
    OFFSET = 300

    @abstractmethod
    def __init__(self, ui, **kw):
        tk.Toplevel.__init__(self, **kw)
        __, x, y = ui.root.geometry().split('+')
        windowGeometry = f'+{int(x)+self.OFFSET}+{int(y)+self.OFFSET}'
        self.geometry(windowGeometry)
        self.grab_set()
        self.focus()



class SnapshotDialog(ModalDialog):

    def __init__(self, view, service, **kw):
        super().__init__(view, **kw)
        self._ui = view
        self._service = service

        self.title(_('Snapshot description'))
        mainWindow = ttk.Frame(self)
        mainWindow.pack(
            fill='both',
            padx=5,
            pady=5
        )
        self._indexCard = IndexCard(mainWindow, bd=2, relief='ridge')
        self._indexCard.bodyBox['height'] = 13
        self._indexCard.bodyBox['width'] = 40
        self._indexCard.pack()

        buttons_frame = ttk.Frame(mainWindow)
        buttons_frame.pack(fill='both')

        ttk.Button(
            buttons_frame,
            text=_('Ok'),
            command=self._set_description,
        ).pack(padx=5, pady=5, side='left')

        ttk.Button(
            buttons_frame,
            text=_('Cancel'),
            command=self.destroy,
        ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            buttons_frame,
            text=_('Online help'),
            command=self._open_help
        ).pack(padx=5, pady=5, side='right')

        self.resizable(False, False)

        self.bind(KEYS.OPEN_HELP[0], self._open_help)

    def _open_help(self, event=None):
        Nvsnapshotshelp.open_help_page()

    def _set_description(self, event=None):
        snapshotTitle = self._indexCard.title.get()
        if not snapshotTitle:
            snapshotTitle = _('Undefined')
        self._service.snapshotTitle = snapshotTitle
        snapshotComment = self._indexCard.bodyBox.get_text()
        if snapshotComment is None:
            snapshotComment = ''
        self._service.snapshotComment = snapshotComment
        self.destroy()
        self._ui.root.event_generate('<<save_snapshot>>')

from datetime import datetime
from tkinter import ttk



class NvsnapshotsMenu(tk.Menu):

    def __init__(self, master, cnf={}, **kw):
        super().__init__(master=master, cnf=cnf, **kw)

        self._fileMenu = tk.Menu(self, tearoff=0)
        self.add_cascade(
            label=_('File'),
            menu=self._fileMenu,
        )
        self._fileMenu.add_command(
            label=_('Open Snapshot folder'),
            command=self._event('<<open_folder>>'),
        )
        self._fileMenu.add_command(
            label=_('Clean up Snapshot folder'),
            command=self._event('<<clean_up>>'),
        )
        self._fileMenu.add_separator()
        self._fileMenu.add_command(
            label=_('Snapshot'),
            accelerator=KEYS.MAKE_SNAPSHOT[1],
            image=icons.get('snapshot', None),
            compound='left',
            command=self._event('<<make_snapshot>>'),
        )
        self._fileMenu.add_separator()
        self._fileMenu.add_command(
            label=_('Remove'),
            accelerator=KEYS.DELETE[1],
            command=self._event('<<remove_snapshot>>'),
        )
        self._fileMenu.add_command(
            label=_('Revert'),
            command=self._event('<<revert>>'),
        )
        self._fileMenu.add_separator()
        self._fileMenu.add_command(
            label=_('Close'),
            accelerator=KEYS.QUIT_PROGRAM[1],
            command=self._event(KEYS.QUIT_PROGRAM[0]),
        )

        self._exportMenu = tk.Menu(self, tearoff=0)
        self.add_cascade(
            label=_('Export'),
            menu=self._exportMenu,
        )
        self._exportMenu.add_command(
            label=_('Manuscript'),
            command=self._event('<<export_manuscript>>'),
        )
        self._exportMenu.add_separator()
        self._exportMenu.add_command(
            label=_('Part descriptions'),
            command=self._event('<<export_parts>>'),
        )
        self._exportMenu.add_command(
            label=_('Chapter descriptions'),
            command=self._event('<<export_chapters>>'),
        )
        self._exportMenu.add_command(
            label=_('Section descriptions'),
            command=self._event('<<export_sections>>'),
        )
        self._exportMenu.add_separator()
        self._exportMenu.add_command(
            label=_('Story structure'),
            command=self._event('<<export_stages>>'),
        )
        self._exportMenu.add_command(
            label=_('Plot line descriptions'),
            command=self._event('<<export_plotlines>>'),
        )
        self._exportMenu.add_command(
            label=_('Plot grid'),
            command=self._event('<<export_grid>>'),
        )
        self._exportMenu.add_separator()
        self._exportMenu.add_command(
            label=_('Character descriptions'),
            command=self._event('<<export_characters>>'),
        )
        self._exportMenu.add_command(
            label=_('Location descriptions'),
            command=self._event('<<export_locations>>'),
        )
        self._exportMenu.add_command(
            label=_('Item descriptions'),
            command=self._event('<<export_items>>'),
        )
        self._exportMenu.add_separator()
        self._exportMenu.add_command(
            label=_('XML data files'),
            command=self._event('<<export_data>>'),
        )

        self._helpMenu = tk.Menu(self, tearoff=0)
        self.add_cascade(
            label=_('Help'),
            menu=self._helpMenu,
        )
        self._helpMenu.add_command(
            label=_('Online help'),
            accelerator=KEYS.OPEN_HELP[1],
            command=self._event('<<open_help>>'),
        )

    def _event(self, sequence):

        def callback(*_):
            root = self.master.winfo_toplevel()
            root.event_generate(sequence)

        return callback



class SnapshotView(tk.Toplevel):

    _COLUMNS = {
        'id':('ID', 'id_width'),
        'title':(_('Title'), 'title_width'),
        'date':(_('Date'), 'date_width'),
        'words_used':(_('Words'), 'words_used_width'),
        'words_total':(_('With unused'), 'words_total_width'),
        'work_phase':(_('Work phase'), 'work_phase_width'),
    }

    def __init__(self, model, view, controller, prefs):
        super().__init__()
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self.prefs = prefs
        self.geometry(f"{self.prefs['window_geometry']}")

        self.title(FEATURE)
        self.lift()
        self.focus()

        self.mainMenu = NvsnapshotsMenu(self)
        self.config(menu=self.mainMenu)

        self._mainWindow = ttk.Frame(self)
        self._mainWindow.pack(
            fill='both',
            padx=2,
            pady=2,
            expand=True,
        )

        self._treeView = ttk.Treeview(
            self._mainWindow,
            columns=tuple(self._COLUMNS),
            show='headings',
            selectmode='browse',
        )
        scrollY = ttk.Scrollbar(
            self._treeView,
            orient='vertical',
            command=self._treeView.yview,
        )
        self._treeView.configure(yscrollcommand=scrollY.set)
        scrollY.pack(side='right', fill='y')
        self._treeView.pack(
            side='left',
            expand=True,
            fill='both',
        )
        self._treeView.bind('<<TreeviewSelect>>', self._on_select_node)
        for colId in self._COLUMNS:
            colText, colWidth = self._COLUMNS[colId]
            self._treeView.column(
                colId,
                width=int(self.prefs.get(colWidth, 100)),
            )
            self._treeView.heading(
                colId,
                text=colText,
                anchor='w',
            )

        self._indexCard = IndexCard(
            self._mainWindow,
            bd=2,
            relief='ridge',
            width=prefs['right_frame_width'],
        )
        self._indexCard.pack(
            side='right',
            expand=False,
            fill='both',
        )
        self._indexCard.pack_propagate(0)

        self.protocol("WM_DELETE_WINDOW", self.on_quit)
        if PLATFORM != 'win':
            self.bind(KEYS.QUIT_PROGRAM[0], self.on_quit)

        self.isOpen = True
        self.element = {}

    def get_selection(self):
        try:
            nodeId = self._treeView.selection()[0]
        except IndexError:
            return None
        else:
            return nodeId

    def reset_tree(self):
        for node in self._treeView.get_children(''):
            self._treeView.delete(node)

    def build_tree(self):
        self.reset_tree()
        for snapshotId in self.snapshots:
            try:
                displayDate = datetime.fromisoformat(
                    self.snapshots[snapshotId]['date']
                ).strftime('%c')
                status = self.snapshots[snapshotId]['work phase']
                if status is not None:
                    workPhase = STATUS[status]
                else:
                    workPhase = _('Undefined')
            except:
                displayDate = self.snapshots[snapshotId]['date']
            columns = [
                snapshotId,
                self.snapshots[snapshotId]['title'],
                displayDate,
                self.snapshots[snapshotId]['words used'],
                self.snapshots[snapshotId]['words total'],
                workPhase,
            ]
            self._treeView.insert(
                '',
                'end',
                snapshotId,
                values=columns,
            )
        self._indexCard.bodyBox.config(state='normal')
        self._indexCard.bodyBox.clear()
        self._indexCard.bodyBox.config(state='disabled')
        self._indexCard.titleEntry.config(state='normal')
        self._indexCard.title.set('')
        self._indexCard.titleEntry.config(state='disabled')

    def on_quit(self, event=None):
        self.update_idletasks()
        self.prefs['window_geometry'] = self.winfo_geometry()
        for i, colId in enumerate(self._COLUMNS):
            width = self._COLUMNS[colId][1]
            self.prefs[width] = self._treeView.column(i, 'width')
        self.destroy()
        self.isOpen = False

    def _on_select_node(self, event=None):
        try:
            self.nodeId = self._treeView.selection()[0]
        except IndexError:
            return

        self.element = self.snapshots[self.nodeId]
        self._set_element_view()

    def _set_element_view(self, event=None):
        self._indexCard.bodyBox.config(state='normal')
        self._indexCard.bodyBox.clear()
        self._indexCard.bodyBox.set_text(self.element.get('description', ''))
        self._indexCard.bodyBox.config(state='disabled')
        self._indexCard.titleEntry.config(state='normal')
        self._indexCard.title.set(self.element.get('title', ''))
        self._indexCard.titleEntry.config(state='disabled')



class SnapshotService(SubController):
    INI_FILENAME = 'snapshots.ini'
    INI_FILEPATH = '.novx/config'
    SETTINGS = dict(
        snapshot_subdir='Snapshots',
        window_geometry='1270x250',
        right_frame_width=350,
        id_width=160,
        title_width=240,
        date_width=120,
        words_used_width=55,
        words_total_width=100,
        work_phase_width=140,
    )
    OPTIONS = {}
    ICON = 'snapshot'

    ZIP_EXTENSION = '.zip'
    DESC_EXTENSION = '.txt'

    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            configDir = '.'
        self.iniFile = f'{configDir}/{self.INI_FILENAME}'
        self.configuration = self._mdl.nvService.new_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS
        )
        self.configuration.read(self.iniFile)
        self.prefs = {}
        self.prefs.update(self.configuration.settings)
        self.prefs.update(self.configuration.options)

        try:
            path = os.path.dirname(sys.argv[0])
            if not path:
                path = '.'
            self.icon = tk.PhotoImage(file=f'{path}/icons/{self.ICON}.png')
        except:
            self.icon = None

        self.snapshotView = None
        self.prjSnapshots = {}

        self._snapshotId = None
        self._isoDate = None
        self._prjFile = None
        self._prjDir = None
        self._zipPath = None

        self._ui.root.bind('<<save_snapshot>>', self._save_snapshot)
        self.snapshotTitle = None
        self.snapshotComment = None

    def disable_menu(self):
        self.snapshotView.mainMenu.entryconfig(_('File'), state='disabled')
        self.snapshotView.mainMenu.entryconfig(_('Export'), state='disabled')

    def enable_menu(self):
        self.snapshotView.mainMenu.entryconfig(_('File'), state='normal')
        self.snapshotView.mainMenu.entryconfig(_('Export'), state='normal')

    def make_snapshot(self, doNotAsk=False, event=None):
        self._ui.restore_status()
        self._ui.propertiesView.apply_changes()
        if self._mdl.prjFile is None:
            return

        if self._mdl.prjFile.filePath is None:
            if not self._ctrl.save_project():
                return

        if self._mdl.isModified:
            if doNotAsk or self._ui.ask_yes_no(
                message=_('Save changes?')
            ):
                self._ctrl.save_project()
            else:
                self._ui.set_status(f'#{_("Action canceled by user")}.')
                return

        os.makedirs(self._get_snapshot_dir(), exist_ok=True)

        self._initialize_snapshot()
        if os.path.isfile(self._zipPath):
            self._ui.set_status(f'#{_("Snapshot already exists")}.')
            return

        SnapshotDialog(self._ui, self)

    def on_close(self):
        self.prjSnapshots.clear()
        self.snapshotView.reset_tree()

    def on_quit(self):
        if self.snapshotView:
            if self.snapshotView.isOpen:
                self.snapshotView.on_quit()

        for keyword in self.prefs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.prefs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.prefs[keyword]
        self.configuration.write(self.iniFile)

    def refresh(self):
        if not self.snapshotView:
            return

        if not self.snapshotView.isOpen:
            return

        self._collect_snapshots()
        self.snapshotView.snapshots = self.prjSnapshots
        self.snapshotView.build_tree()

    def start_manager(self):

        if self.snapshotView:
            if self.snapshotView.isOpen:
                if self.snapshotView.state() == 'iconic':
                    self.snapshotView.state('normal')
                self.snapshotView.lift()
                self.snapshotView.focus()
                return

        self.snapshotView = SnapshotView(
            self._mdl,
            self._ui,
            self._ctrl,
            self.prefs,
        )
        if self.icon:
            self.snapshotView.iconphoto(False, self.icon)

        self._bind_events()
        self.refresh()

    def _bind_events(self):
        event_callbacks = {
            '<<clean_up>>': self._clean_up_snapshot_dir,
            '<<export_characters>>': self._export_characters,
            '<<export_chapters>>': self._export_chapters,
            '<<export_data>>': self._export_data,
            '<<export_grid>>': self._export_grid,
            '<<export_items>>': self._export_items,
            '<<export_locations>>': self._export_locations,
            '<<export_manuscript>>': self._export_manuscript,
            '<<export_sections>>': self._export_sections,
            '<<export_stages>>': self._export_stages,
            '<<export_parts>>': self._export_parts,
            '<<export_plotlines>>': self._export_plotlines,
            '<<make_snapshot>>': self.make_snapshot,
            '<<open_help>>': self._open_help,
            '<<remove_snapshot>>': self._remove_snapshot,
            '<<revert>>': self._revert,
            '<<open_folder>>': self._open_folder,
        }
        for sequence, callback in event_callbacks.items():
            self.snapshotView.bind(sequence, callback)
        self.snapshotView.bind(KEYS.MAKE_SNAPSHOT[0], self.make_snapshot)
        self.snapshotView.bind(KEYS.OPEN_HELP[0], self._open_help)
        self.snapshotView.bind(KEYS.DELETE[0], self._remove_snapshot)

    def _clean_up_snapshot_dir(self, event=None):
        snapshotDir = self._get_snapshot_dir()
        if not os.path.isdir(snapshotDir):
            return

        for pattern in (
            '*.bak',
            '*.od?',
            '*.xml',
        ):
            for file in glob.iglob(
                pattern,
                root_dir=snapshotDir,
            ):
                try:
                    os.remove(os.path.join(snapshotDir, file))
                except:
                    pass

    def _collect_snapshots(self):
        projectDir, projectFile = os.path.split(self._mdl.prjFile.filePath)
        snapshotDir = os.path.join(projectDir, self.prefs['snapshot_subdir'])
        if not os.path.isdir(snapshotDir):
            return

        self.prjSnapshots.clear()
        prjName, __ = os.path.splitext(projectFile)
        prjSnapshotFiles = glob.glob(
            f'{prjName}.*{self.ZIP_EXTENSION}',
            root_dir=snapshotDir,
        )
        prjSnapshotFiles.sort()
        if not prjSnapshotFiles:
            return

        for snapshotFile in prjSnapshotFiles:
            zipPath = os.path.join(snapshotDir, snapshotFile)
            try:
                with zipfile.ZipFile(zipPath, 'r') as z:
                    with z.open('meta.json', 'r') as f:
                        metadata = json.loads(f.read())
            except:
                pass
            else:
                self.prjSnapshots |= metadata

    def _create_document(self, sourcePath, suffix, **kwargs):
        self._ui.restore_status()
        if not os.path.isfile(sourcePath):
            self._ui.set_status(
                f'!{_("File not found")}: '
                f'"{norm_path(sourcePath)}".'
            )
            return

        __, extension = os.path.splitext(sourcePath)
        if extension == self._mdl.nvService.get_novx_file_extension():
            novxFile = self._mdl.nvService.new_novx_file(sourcePath)
        elif extension == self._mdl.nvService.get_zipped_novx_file_extension():
            novxFile = self._mdl.nvService.new_zipped_novx_file(sourcePath)
        else:
            self._ui.set_status(f'!{_("File type is not supported")}.')
            return

        novxFile.novel = self._mdl.nvService.new_novel()
        try:
            novxFile.read()
            self._ui.set_status(
                self._ctrl.fileManager.exporter.run(
                    novxFile,
                    suffix,
                    **kwargs
                )
            )
        except UserWarning as ex:
            self._ui.set_status(f'#{str(ex)}')
        except Exception as ex:
            self._ui.set_status(f'!{str(ex)}')

    def _export_document(self, suffix, show=True, event=None):
        self._ui.restore_status()
        snapshotId = self.snapshotView.get_selection()
        if snapshotId is None:
            return

        self._create_document(
            self._get_zipfile_path(snapshotId),
            suffix,
            overwrite=True,
            ask=True,
            show=show,
        )

    def _export_characters(self, event=None):
        self._export_document(CHARACTERS_SUFFIX, event=event)

    def _export_chapters(self, event=None):
        self._export_document(CHAPTERS_SUFFIX, event=event)

    def _export_data(self, event=None):
        self._export_document(DATA_SUFFIX, show=False, event=event)

    def _export_grid(self, event=None):
        self._export_document(GRID_SUFFIX, event=event)

    def _export_items(self, event=None):
        self._export_document(ITEMS_SUFFIX, event=event)

    def _export_locations(self, event=None):
        self._export_document(LOCATIONS_SUFFIX, event=event)

    def _export_manuscript(self, event=None):
        self._export_document(MANUSCRIPT_SUFFIX, event=event)

    def _export_parts(self, event=None):
        self._export_document(PARTS_SUFFIX, event=event)

    def _export_plotlines(self, event=None):
        self._export_document(PLOTLINES_SUFFIX, event=event)

    def _export_sections(self, event=None):
        self._export_document(SECTIONS_SUFFIX, event=event)

    def _export_stages(self, event=None):
        self._export_document(STAGES_SUFFIX, event=event)

    def _get_snapshot_dir(self):
        projectDir, __ = os.path.split(self._mdl.prjFile.filePath)
        return os.path.join(
            projectDir,
            self.prefs.get('snapshot_subdir', ''),
        )

    def _get_zipfile_path(self, snapshotId):
        return os.path.join(
            self._get_snapshot_dir(),
            f'{snapshotId}{self.ZIP_EXTENSION}'
        )

    def _initialize_snapshot(self):
        self._prjDir, self._prjFile = os.path.split(self._mdl.prjFile.filePath)
        prjName, __ = os.path.splitext(self._prjFile)
        prjFileTimestamp = os.path.getmtime(self._mdl.prjFile.filePath)
        prjFileDate = (datetime.fromtimestamp(prjFileTimestamp))
        self._isoDate = prjFileDate.replace(microsecond=0).isoformat()
        self._snapshotId = f"{prjName}.{self._isoDate.replace(':', '.')}"
        self._zipPath = self._get_zipfile_path(self._snapshotId)

    def _open_folder(self, event=None):
        snapshotDir = self._get_snapshot_dir()
        os.makedirs(snapshotDir, exist_ok=True)
        open_document(snapshotDir)

    def _open_help(self, event=None):
        Nvsnapshotshelp.open_help_page()

    def _remove_snapshot(self, event=None):
        self._ui.restore_status()
        snapshotId = self.snapshotView.get_selection()
        if snapshotId is None:
            return

        try:
            if self._ui.ask_yes_no(
                message=_('Delete the selected snapshot?'),
                detail=self.prjSnapshots[snapshotId].get('title', ''),
                title=FEATURE,
                parent=self.snapshotView,
            ):
                os.remove(self._get_zipfile_path(snapshotId))
                self.refresh()
        except ValueError as ex:
            self._ui.set_status(
                f'!{_("Can not remove snapshot")}: '
                f'{str(ex)}'
            )

    def _revert(self, event=None):
        self._ui.restore_status()

        if self._ctrl.check_lock():
            return

        snapshotIdToRestore = self.snapshotView.get_selection()
        if snapshotIdToRestore is None:
            return

        self._initialize_snapshot()
        if (
            not os.path.isfile(self._zipPath)
            or self._mdl.isModified
        ):
            if self._mdl.isModified:
                self._ctrl.save_project()
                self._initialize_snapshot()
            self.snapshotTitle = _('Auto-generated snapshot')
            self.snapshotComment = _('Before reverting to {} \n"{}"').format(
                    snapshotIdToRestore,
                    self.prjSnapshots[snapshotIdToRestore]['title']
                )
            self._save_snapshot()
        zipFileToRestore = self._get_zipfile_path(snapshotIdToRestore)
        try:
            with zipfile.ZipFile(zipFileToRestore, 'r') as z:
                z.extract(
                    self._prjFile,
                    path=self._prjDir,
                )
            self._ctrl.open_project(
                filePath=self._mdl.prjFile.filePath,
                doNotSave=True,
            )
        except Exception as ex:
            message = (
                f'!{_("Can not restore snapshot")}: '
                f'{str(ex)}'
            )
        else:
            message = (
                f'{_("Snapshot restored")}: '
                f'"{snapshotIdToRestore}"'
            )
        finally:
            self._ui.set_status(message)

    def _sanitize_filename(self, filename):
        return re.sub(r'[\\|\/|\:|\*|\?|\"|\<|\>|\|]+', '', filename)

    def _save_snapshot(self, event=None):
        wordCount, totalCount = self._mdl.prjFile.count_words()
        snapshotMetadata = {
            self._snapshotId: {
                'title': self.snapshotTitle,
                'description': self.snapshotComment,
                'date': self._isoDate,
                'work phase': self._mdl.novel.workPhase,
                'words used': wordCount,
                'words total':totalCount,
            }
        }

        try:
            with zipfile.ZipFile(self._zipPath, 'w') as z:

                z.write(
                    self._mdl.prjFile.filePath,
                    arcname=self._prjFile,
                    compress_type=zipfile.ZIP_DEFLATED,
                )

                z.writestr(
                    (
                        f'{self._sanitize_filename(self.snapshotTitle)}'
                        f'{self.DESC_EXTENSION}'
                    ),
                    f'{self.snapshotTitle}\n\n{self.snapshotComment}',
                    compress_type=zipfile.ZIP_DEFLATED,
                )

                z.writestr(
                    'meta.json',
                    json.dumps(snapshotMetadata),
                    compress_type=zipfile.ZIP_DEFLATED,
                )

        except Exception as ex:
            message = f'!{_("Snapshot failed")}: {str(ex)}'
        else:
            message = f'{_("Snapshot generated")} ({self._isoDate})'
        self._ui.set_status(message)
        self.refresh()



class Plugin(PluginBase):
    VERSION = '5.2.2'
    API_VERSION = '5.44'
    DESCRIPTION = 'A snapshot manager'
    URL = 'https://github.com/peter88213/nv_snapshots'

    def disable_menu(self):
        self.snapshotService.disable_menu()

    def enable_menu(self):
        self.snapshotService.enable_menu()

    def install(self, model, view, controller):
        """Add a submenu to the 'File' menu.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self.snapshotService = SnapshotService(model, view, controller)
        icons['snapshot'] = self._icon = self._get_icon('snapshot.png')


        pos = self._ui.fileMenu.index(_('Save')) - 1
        self._ui.fileMenu.insert_separator(pos)
        pos += 1

        label = _('Snapshot')
        self._ui.fileMenu.insert_command(
            pos,
            label=label,
            accelerator=KEYS.MAKE_SNAPSHOT[1],
            image=self._icon,
            compound='left',
            command=self.make_snapshot,
            state='disabled',
        )
        self._ui.fileMenu.disableOnClose.append(label)

        label = FEATURE
        self._ui.toolsMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=self.start_manager,
            state='disabled',
        )
        self._ui.toolsMenu.disableOnClose.append(label)

        label = _('Snapshots plugin Online help')
        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=self.open_help,
        )

        self._ui.root.bind(KEYS.MAKE_SNAPSHOT[0], self.make_snapshot)

    def on_close(self):
        self.snapshotService.on_close()

    def on_open(self):
        self.snapshotService.refresh()

    def on_quit(self):
        self.snapshotService.on_quit()

    def open_help(self, event=None):
        Nvsnapshotshelp.open_help_page()

    def start_manager(self):
        self.snapshotService.start_manager()

    def make_snapshot(self, event=None):
        self.snapshotService.make_snapshot()

